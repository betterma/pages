# OKX DEX K 线缓存（定时事件函数）

**只需要定时触发器**，不需要 HTTP。

定时读取 `okx/favorites.json` → 调 OKX `historical-candles` → 写回 `okx/candles-cache.json`。  
页面 `okx/kline.html` 只读缓存，密钥不进 Pages。

## 部署

1. 上传本目录，Handler：`index.handler`，Node.js 18+
2. 添加**定时触发器**（建议 5～15 分钟）
3. 环境变量：

| 变量 | 说明 |
|------|------|
| `OKX_API_KEY` | Onchain OS API Key |
| `OKX_SECRET_KEY` | Secret |
| `OKX_PASSPHRASE` | Passphrase |
| `GITHUB_TOKEN` | 可读写仓库 `okx/favorites.json`、`okx/candles-cache.json` |
| `GITHUB_REPO` | 默认 `betterma/pages` |
| `OKX_CANDLE_BAR` | 可选，默认 `4H` |
| `OKX_CANDLE_LIMIT` | 可选，默认 `72`（约 10 天） |
| `OKX_CHAINS` | 可选，默认 `501,4663` |

## 说明

- 新加自选后，要等**下一次定时**才会出现 K 线
- 近 3 天 / 近 10 天切换在前端截取，不必改函数
